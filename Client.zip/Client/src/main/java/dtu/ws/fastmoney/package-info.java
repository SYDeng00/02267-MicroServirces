@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://fastmoney.ws.dtu/")
package dtu.ws.fastmoney;
