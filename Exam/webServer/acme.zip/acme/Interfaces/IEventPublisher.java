package org.acme.Interfaces;

import org.acme.Domains.Event;

public interface IEventPublisher {
    void sendEvent(Event event) throws Exception;

}
