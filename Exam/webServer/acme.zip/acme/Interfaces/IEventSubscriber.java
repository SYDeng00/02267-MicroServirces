package org.acme.Interfaces;

import org.acme.Domains.Event;

public interface IEventSubscriber {
    void receiveEvent(Event event) throws Exception;
    void generateReply(Event event);
}
