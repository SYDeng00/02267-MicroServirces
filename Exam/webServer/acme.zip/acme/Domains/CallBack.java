package org.acme.Domains;

public class CallBack {
    
}
