/*
package org.acme.Resource;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.acme.Domain.Token;
import org.acme.business_logic.TokenManagementServices;

import java.util.List;

@Path("/")
public class TokenResourceRest {
TokenManagementServices tokenManagementServices = new TokenManagementServices();
    */
/*@Path("/tokens")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Token> getAllToken() {
        return tokenManagementServices.getAllTokenList();
    }*//*

   */
/* @Path("/tokens/")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public List<String> getTokenSet(Token token) {
        return tokenManagementServices.generateTokens(token);
    }*//*

}
*/
