package main.java.org.acme.token_facade.Resources;

public class TokenFacadeConfig {

    public static final String SEND_RETURN_TOKEN = "requestTokens";
    public static final String RECEIVE_RETURN_TOKEN = "sendTokens";
    public static final String SEND_TOKEN_REQUEST = "RequestTokens";
}
