package main.java.org.acme.account_facade.Resources;

public class AccountConfig {
    public static final String REGISTER = "Register";
    public static final String RETURN_ID = "return ID";

	
}
